
const SCAM_PATTERNS=[
{pat:/bhejo.*paisa|paisa.*bhejo|urgent.*paisa|easy.*paisa|lottery.*jeeta|inam.*jeeta/gi,score:0.95,reason:"Paisa mangnay wala scam"},
{pat:/bank.*detail|account.*number|CNIC.*bhejo|OTP.*bhejo|verify.*account/gi,score:0.92,reason:"Bank/CNIC OTP scam"},
{pat:/link.*click|click.*here|free.*recharge|free.*internet|whatsapp.*gold/gi,score:0.88,reason:"Fake link / free recharge"},
{pat:/ammi.*hospital|abu.*accident|emergency.*paisa|help.*urgent/gi,score:0.90,reason:"Emotional blackmail scam"},
{pat:/job.*offer|ghar.*beth.*paisa|online.*kamai|1000.*daily/gi,score:0.85,reason:"Fake job / online earning"}
];
function scanMessage(text){
  let maxScore=0,reasons=[];
  for(let p of SCAM_PATTERNS){ if(p.pat.test(text)){maxScore=Math.max(maxScore,p.score);reasons.push(p.reason);} }
  const words=["foran","abhi","warna","block","suspend"]; let c=words.filter(w=>text.toLowerCase().includes(w)).length;
  if(c>=2) maxScore=Math.min(0.99,maxScore+0.1);
  return {score:maxScore,reasons};
}
function injectShield(){
  const main=document.querySelector('#main');
  if(!main || document.getElementById('sameel-shield')) return;
  const wrap=document.createElement('div');
  wrap.id='sameel-shield';
  wrap.innerHTML='<div style="background:linear-gradient(135deg,#25D366,#128C7E);color:white;padding:10px 14px;border-radius:24px;font-family:Arial;font-size:12px;font-weight:bold;box-shadow:0 4px 12px rgba(0,0,0,0.15);display:flex;align-items:center;gap:8px;position:sticky;top:10px;z-index:9999;margin:10px;"><span style=\"font-size:16px\">🛡️</span> WhatsApp Scam Shield v2.0 by Sameel | <span style=\"background:rgba(255,255,255,0.2);padding:2px 8px;border-radius:10px;font-size:10px\">O-Levels 93.75%</span> <span id=\"shield-count\" style=\"margin-left:auto;font-size:10px;opacity:0.9\">Scanning...</span></div><div id=\"shield-alert\" style=\"display:none;margin:10px;padding:14px;background:#ffebee;border-left:4px solid #f44336;border-radius:12px;font-family:Arial;font-size:13px;box-shadow:0 2px 8px rgba(0,0,0,0.1)\"></div>';
  main.prepend(wrap);
  let count=0, blocked=0;
  const obs=new MutationObserver(()=>{
    const msgs=document.querySelectorAll('span.selectable-text');
    msgs.forEach(el=>{
      if(el.dataset.scanned) return; el.dataset.scanned="1"; count++;
      const res=scanMessage(el.innerText);
      if(res.score>0.7){
        blocked++; el.style.background=res.score>0.9?'#ffcdd2':'#fff9c4'; el.style.border='2px solid #f44336'; el.style.borderRadius='8px'; el.title=`⚠️ SCAM ${Math.round(res.score*100)}% - ${res.reasons.join(', ')}`;
        const alertBox=document.getElementById('shield-alert');
        if(alertBox){
          alertBox.style.display='block';
          alertBox.innerHTML=`<div style=\"display:flex;justify-content:space-between;align-items:start\"><div><b style=\"color:#c62828\">🚨 Scam Detected (${Math.round(res.score*100)}%)</b><br><span style=\"font-size:12px\">${res.reasons.join('<br>')}</span><br><small style=\"color:#666\">\"${el.innerText.slice(0,90)}...\"</small></div><button id=\"dismiss-alert\" style=\"background:#f44336;color:white;border:none;border-radius:6px;padding:6px 10px;cursor:pointer;font-size:11px\">✕</button></div>`;
          const dis=document.getElementById('dismiss-alert'); if(dis) dis.addEventListener('click',()=>alertBox.style.display='none');
        }
      }
      const cnt=document.getElementById('shield-count'); if(cnt) cnt.textContent=`Scanned: ${count} | Blocked: ${blocked}`;
      chrome.storage.local.set({count,blocked});
    });
  });
  obs.observe(document.body,{childList:true,subtree:true});
}
setInterval(injectShield,2000);
injectShield();
console.log("WhatsApp Scam Shield v2.0 Flagship by Sameel loaded");
