
function updateStats(){
  chrome.storage.local.get(['count','blocked'], (r)=>{
    document.getElementById('count').textContent = r.count||0;
    document.getElementById('blocked').textContent = r.blocked||0;
  });
}
document.getElementById('openWA').addEventListener('click', ()=> chrome.tabs.create({url:'https://web.whatsapp.com'}));
document.getElementById('openPortfolio').addEventListener('click', ()=> chrome.tabs.create({url:'https://sameelzaman21-commits.github.io/'}));
document.getElementById('resetBtn').addEventListener('click', async ()=>{
  await chrome.storage.local.set({count:0, blocked:0});
  updateStats();
});
updateStats();
