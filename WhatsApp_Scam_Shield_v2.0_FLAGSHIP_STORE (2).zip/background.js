
chrome.runtime.onInstalled.addListener((details)=>{
  if(details.reason==='install'){
    chrome.tabs.create({url: chrome.runtime.getURL('welcome.html')});
  }
});
chrome.storage.local.get(['onboarded'], (r)=>{
  if(!r.onboarded){
    chrome.storage.local.set({onboarded:false, count:0, blocked:0});
  }
});
