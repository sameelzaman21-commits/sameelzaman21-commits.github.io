
document.getElementById('grantBtn').addEventListener('click', async ()=>{
  const btn = document.getElementById('grantBtn');
  btn.textContent = '⏳ Activating...';
  btn.disabled = true;
  await chrome.storage.local.set({onboarded:true, count:0, blocked:0, grantedAt: new Date().toISOString()});
  btn.textContent = '✅ Activated! Opening WhatsApp...';
  setTimeout(()=>{
    chrome.tabs.create({url:'https://web.whatsapp.com'});
    window.close();
  }, 1000);
});
