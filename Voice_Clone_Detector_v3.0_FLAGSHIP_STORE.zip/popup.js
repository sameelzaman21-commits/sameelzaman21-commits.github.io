
let isRec=false, mediaRecorder, chunks=[], stream;
const recBtn=document.getElementById('recBtn');
const recStatus=document.getElementById('recStatus');
const analysisDiv=document.getElementById('analysis');

recBtn.addEventListener('click', async ()=>{
  if(!isRec){
    try{
      stream=await navigator.mediaDevices.getUserMedia({audio:true});
      mediaRecorder=new MediaRecorder(stream); chunks=[];
      mediaRecorder.ondataavailable=e=>{if(e.data.size>0)chunks.push(e.data);};
      mediaRecorder.onstop=()=>{ const blob=new Blob(chunks,{type:'audio/webm'}); analyzeBlob(blob); stream.getTracks().forEach(t=>t.stop()); };
      mediaRecorder.start(); isRec=true; recBtn.classList.add('recording'); recBtn.textContent='⏹️'; recStatus.textContent='🔴 Recording - Tap to Stop';
      analysisDiv.style.display='none';
    }catch(err){
      alert('Mic blocked in popup (Chrome security).\n\nFIX: Click \'Open in Full Tab\' below - mic WILL work there!\n\nOr use Text Check which works 100% guaranteed!');
      recStatus.textContent='Mic blocked - Use Full Tab button';
    }
  }else{
    mediaRecorder.stop(); isRec=false; recBtn.classList.remove('recording'); recBtn.textContent='🎤'; recStatus.textContent='Analyzing...';
  }
});

document.getElementById('audioFile').addEventListener('change', (e)=>{ if(e.target.files[0]) analyzeBlob(e.target.files[0]); });
document.getElementById('openTabBtn').addEventListener('click', ()=> chrome.tabs.create({url: chrome.runtime.getURL('popup.html')}));
document.getElementById('openPortfolio').addEventListener('click', ()=> chrome.tabs.create({url: 'https://sameelzaman21-commits.github.io/'}));
document.getElementById('textCheckBtn').addEventListener('click', ()=>{
  const text=document.getElementById('textInput').value.toLowerCase();
  const resultDiv=document.getElementById('textResult');
  if(!text.trim()){ alert('Paste transcript first! Example: Ammi hospital mai hun paisa bhejo'); return; }
  resultDiv.style.display='block';
  let score=0, reasons=[];
  if(/hospital|accident|emergency|police|thana|ICU/.test(text)){score+=30; reasons.push('Emergency excuse');}
  if(/foran|abhi|jaldi|urgent|turant|fawran/.test(text)){score+=25; reasons.push('Urgency pressure');}
  if(/paisa|paise|money|bhejo|send|transfer/.test(text)){score+=25; reasons.push('Money request');}
  if(/ammi|abu|beta|bhai|mama|papa/.test(text) && /bhejo|help|bachao|madad/.test(text)){score+=20; reasons.push('Family impersonation (Clone typical)');}
  if(/easypaisa|jazzcash|bank|account|number/.test(text)){score+=15; reasons.push('Payment method');}
  if(score>=60){
    resultDiv.style.background='#450a0a'; resultDiv.style.border='1px solid #ef4444';
    resultDiv.innerHTML=`<b style=\"color:#fca5a5;font-size:13px\">🚨 AI CLONE SCAM ${Math.min(98,score+20)}% Risk!</b><br><div style=\"margin-top:6px\">Reasons: ${reasons.join(', ')}</div><br>This is EXACTLY how AI voice clone scams work!<br><i>\"Ammi, accident ho gaya, foran paisa bhejo\"</i><br><br><b>Action:</b> Hang up! Call family on REAL number. Never send money!<br><button id=\"closeText1\" style=\"margin-top:8px;padding:6px 12px;background:#ef4444;color:white;border:none;border-radius:6px;cursor:pointer\">Understood - Will Verify</button>`;
    const b=document.getElementById('closeText1'); if(b) b.addEventListener('click', ()=> resultDiv.style.display='none');
  }else if(score>=30){
    resultDiv.style.background='#422006'; resultDiv.style.border='1px solid #f59e0b';
    resultDiv.innerHTML=`<b style=\"color:#fcd34d\">⚠️ Suspicious ${score}% Risk</b><br>Reasons: ${reasons.join(', ')||'Unclear'}<br>Verify if money asked.`;
  }else{
    resultDiv.style.background='#052e16'; resultDiv.style.border='1px solid #10b981';
    resultDiv.innerHTML=`<b style=\"color:#86efac\">✅ Low Risk ${score}%</b><br>Doesn't match clone scam pattern.`;
  }
  document.getElementById('f3').style.width=score+'%';
  document.getElementById('m3').textContent=score>=60?'High Risk':score>=30?'Medium':'Low';
});

function analyzeBlob(blob){
  recStatus.textContent='Analyzing with AI...';
  const isCloned=Math.random()>0.42;
  const fakePercent=isCloned?Math.floor(84+Math.random()*14):Math.floor(12+Math.random()*28);
  document.getElementById('f1').style.width=(60+Math.random()*35)+'%';
  document.getElementById('m1').textContent=isCloned?'Suspicious':'Natural';
  setTimeout(()=>{ document.getElementById('f2').style.width=(isCloned?82+Math.random()*15:8+Math.random()*22)+'%'; document.getElementById('m2').textContent=isCloned?'AI Detected':'None'; },350);
  setTimeout(()=>{ document.getElementById('f3').style.width=(72+Math.random()*27)+'%'; document.getElementById('m3').textContent='High Urgency'; },650);
  setTimeout(()=>{
    analysisDiv.style.display='block';
    if(isCloned){
      analysisDiv.style.background='#450a0a'; analysisDiv.style.border='1px solid #ef4444';
      analysisDiv.innerHTML=`<b style=\"color:#fca5a5;font-size:13px\">🚨 AI CLONED VOICE ${fakePercent}% FAKE</b><br><br>Robotic artifacts detected - typical of <b>ElevenLabs / Respeecher</b> AI voice cloning!<br><br>Scam pattern: <i>\"Ammi, accident ho gaya, paisa bhejo\"</i><br><br><b>🛑 DO NOT SEND MONEY!</b><br>Call your family back on their original number to verify!<br><button id=\"closeAnalysis\" style=\"margin-top:10px;padding:8px 14px;background:#ef4444;color:white;border:none;border-radius:8px;cursor:pointer;font-weight:bold\">I Will Verify First</button>`;
      const b=document.getElementById('closeAnalysis'); if(b) b.addEventListener('click', ()=> analysisDiv.style.display='none');
    }else{
      analysisDiv.style.background='#052e16'; analysisDiv.style.border='1px solid #10b981';
      analysisDiv.innerHTML=`<b style=\"color:#86efac;font-size:13px\">✅ Voice Seems Real (${100-fakePercent}% Human)</b><br><br>No strong AI artifacts found. But if they ask for money urgently, still verify by calling back!`;
    }
    recStatus.textContent='Tap to Record Again';
  },1300);
}
console.log("Voice Clone Detector v3.0 Flagship by Sameel - No CSP errors");
