
document.getElementById('grantBtn').addEventListener('click', async ()=>{
  const b=document.getElementById('grantBtn');
  b.textContent='⏳ Initializing AI Engine...'; b.disabled=true;
  await chrome.storage.local.set({onboarded:true, version:'3.0', grantedAt: new Date().toISOString()});
  b.textContent='✅ Ready! Opening Detector...';
  setTimeout(()=>{ window.close(); }, 800);
});
