
chrome.runtime.onInstalled.addListener((d)=>{
  if(d.reason==='install'){
    chrome.tabs.create({url: chrome.runtime.getURL('welcome.html')});
  }
});
