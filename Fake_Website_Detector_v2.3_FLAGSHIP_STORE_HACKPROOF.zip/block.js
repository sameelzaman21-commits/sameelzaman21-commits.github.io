'use strict';
(function(){
  try{
    const params = new URLSearchParams(location.search);
    const hostEl = document.getElementById("host");
    const urlEl = document.getElementById("url");
    const typeEl = document.getElementById("type");
    const reasonEl = document.getElementById("reason");
    const keywordEl = document.getElementById("keyword");
    const continueLink = document.getElementById("continueLink");

    const host = params.get("host") || "Unknown scam domain";
    const url = params.get("url") || "";
    const type = params.get("type") || "Fake Secure Domain";
    const reason = params.get("reason") || "This website uses Easypaisa/JazzCash name in a fake way to steal your money. Official domains never use -secure/-verify/-bonus. This is NOT good.";
    const keyword = params.get("keyword") || "-";

    if(hostEl) hostEl.textContent = host;
    if(urlEl) urlEl.textContent = url;
    if(typeEl) typeEl.textContent = type;
    if(reasonEl) reasonEl.textContent = reason;
    if(keywordEl) keywordEl.textContent = keyword;

    // Increment counter - safe
    if(chrome && chrome.storage && chrome.storage.local){
      chrome.storage.local.get(["blockedCount"], (r)=>{
        const c = (r.blockedCount||0)+1;
        chrome.storage.local.set({blockedCount:c});
      });
    }

    const backBtn = document.getElementById("backBtn");
    if(backBtn) backBtn.addEventListener("click", ()=>{ history.back(); setTimeout(()=>{ window.close(); }, 300); });

    const closeBtn = document.getElementById("closeBtn");
    if(closeBtn) closeBtn.addEventListener("click", ()=>{ window.close(); try{ chrome.tabs && chrome.tabs.getCurrent && chrome.tabs.getCurrent((t)=>{ if(t) chrome.tabs.remove(t.id); }); }catch(e){} });

    // Optional risky continue - only if user really wants, keep hidden by default for safety, show after 3 seconds
    setTimeout(()=>{
      if(continueLink && url){
        continueLink.style.display = "inline-flex";
        continueLink.href = url;
        continueLink.addEventListener("click", (e)=>{
          if(!confirm("⚠️ WARNING: This website is NOT good and may steal your Easypaisa/JazzCash money! Are you sure you want to continue?")){ e.preventDefault(); }
        });
      }
    }, 3000);

  }catch(e){ console.error("Block v2.3 error", e); }
})();
