// Content v2.3 - Hack proof - no inline eval
(function(){
  'use strict';
  try{
    const host = location.hostname;
    if(!host || location.href.includes("block.html")) return;
    chrome.runtime.sendMessage({action:"checkDomain", host}, (res)=>{
      try{
        if(chrome.runtime.lastError) return;
        if(!res || !res.isScam) return;
        const existing = document.getElementById("fwd-banner-v23");
        if(existing) return;
        const banner = document.createElement("div");
        banner.id="fwd-banner-v23";
        banner.setAttribute("style","position:fixed;top:0;left:0;right:0;z-index:2147483647;background:linear-gradient(90deg,#ff0844,#ffb199);color:white;padding:12px 20px;font-family:Inter,system-ui,sans-serif;font-size:13px;display:flex;align-items:center;justify-content:space-between;box-shadow:0 4px 20px rgba(0,0,0,0.3);line-height:1.4");
        const safeHost = host.replace(/</g,"&lt;");
        const reason = (res.details && res.details.reason ? res.details.reason.replace(/</g,"&lt;") : "Fake website detected");
        banner.innerHTML = '<span>🚨 SCAM: <b>'+safeHost+'</b> NOT good! '+reason+' | Official: easypaisa.com.pk</span><button id="fwd-close-v23" style="background:white;color:#ff0844;border:none;padding:6px 14px;border-radius:6px;cursor:pointer;font-weight:800;margin-left:12px;flex-shrink:0">Close</button>';
        if(document.documentElement) document.documentElement.insertBefore(banner, document.documentElement.firstChild);
        const btn = document.getElementById("fwd-close-v23");
        if(btn) btn.addEventListener("click", ()=>{ try{ chrome.runtime.sendMessage({action:"closeTab"}); window.close(); }catch(e){} });
      }catch(e){}
    });
  }catch(e){}
})();
