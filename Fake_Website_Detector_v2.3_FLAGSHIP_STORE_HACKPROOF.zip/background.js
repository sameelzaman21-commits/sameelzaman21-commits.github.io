// Fake Website Detector v2.3 FLAGSHIP STORE - Hack Proof - No Errors - CSP Compliant
'use strict';
const OFFICIAL_DOMAINS = [
  "easypaisa.com.pk","easypaisa.com","jazzcash.com.pk","jazzcash.com",
  "hbl.com","hbl.com.pk","ubl.com.pk","mcb.com.pk","alliedbank.com.pk",
  "meezanbank.com","bankalhabib.com","askari.com.pk","faysalbank.com",
  "standardchartered.com.pk","alfalah.com.pk","sadaapay.pk","nayapay.com",
  "daraz.pk","foodpanda.pk","careem.com","bykea.pk","jazz.com.pk"
];
const SCAM_KEYWORDS = ["easypaisa","jazzcash","easypaisa-secure","jazzcash-secure","jazzcash-verify","easypaisa-verify","easypaisa-bonus","jazzcash-bonus","bank-verify","secure-login","account-verify"];
const SCAM_PATTERNS = ["-secure.pk","-verify.pk","-bonus.pk","-offer.pk","-login.pk","-account.pk","secure-easypaisa","secure-jazzcash","easypaisa-secure","jazzcash-secure"];
const TYPO_DOMAINS = ["eazypaisa","esaypaisa","easypasia","jazzcach","jazzcas","easyapisa","ezypaisa"];

function isOfficial(host){
  host = host.toLowerCase();
  return OFFICIAL_DOMAINS.some(o => host === o || host.endsWith("."+o));
}
function analyze(host){
  if(!host) return null;
  const h = host.toLowerCase();
  if(isOfficial(h)) return null;
  // Typosquat
  for(const t of TYPO_DOMAINS){ if(h.includes(t)) return {type:"Typosquat", keyword:t, reason:`Typo-squatting '${t}' mimics official brand. Official is easypaisa.com.pk / jazzcash.com.pk`}; }
  // Contains easypaisa/jazzcash but not official
  if((h.includes("easypaisa")||h.includes("jazzcash")) && !isOfficial(h)){
    for(const kw of SCAM_KEYWORDS){ if(h.includes(kw)) return {type:"Fake Brand Domain", keyword:kw, reason:`Domain contains '${kw}' but is NOT official. Scammers use this name to steal money. Official: easypaisa.com.pk / jazzcash.com.pk`}; }
    // Generic contain
    return {type:"Brand Impersonation", keyword:h.includes("easypaisa")?"easypaisa":"jazzcash", reason:"This domain uses Easypaisa/JazzCash name but is NOT official. Official domains are easypaisa.com.pk and jazzcash.com.pk only."};
  }
  for(const p of SCAM_PATTERNS){ if(h.includes(p)) return {type:"Fake Secure Domain", keyword:p, reason:`Fake '${p}' pattern detected. Scammers use secure/verify/bonus tricks to steal Easypaisa/JazzCash logins. Real banks never use -secure/-verify.`}; }
  return null;
}

chrome.webNavigation.onBeforeNavigate.addListener((details)=>{
  if(details.frameId!==0) return;
  try{
    const url = new URL(details.url);
    const host = url.hostname;
    if(!host) return;
    // skip chrome internal and block.html itself
    if(host==="") return;
    if(details.url.includes("block.html")) return;
    const result = analyze(host);
    if(result){
      chrome.storage.local.get(["blockedCount","lastBlocks"], (data)=>{
        const count = (data.blockedCount||0)+1;
        const blocks = data.lastBlocks||[];
        blocks.unshift({host, url:details.url, ...result, time:Date.now()});
        chrome.storage.local.set({blockedCount:count, lastBlocks:blocks.slice(0,20), lastScam:{host,url:details.url,...result,time:Date.now()}});
      });
      const blockUrl = chrome.runtime.getURL("block.html") + "?host=" + encodeURIComponent(host) + "&url=" + encodeURIComponent(details.url) + "&type=" + encodeURIComponent(result.type) + "&reason=" + encodeURIComponent(result.reason) + "&keyword=" + encodeURIComponent(result.keyword||"");
      chrome.tabs.update(details.tabId, {url:blockUrl});
    }
  }catch(e){ console.error("FWD v2.3 error", e); }
});

chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
  try{
    if(msg.action==="checkDomain"){
      const host = msg.host||"";
      const scam = analyze(host);
      sendResponse({isScam:!!scam, details:scam, isOfficial:isOfficial(host)});
      return true;
    }
    if(msg.action==="closeTab" && sender.tab){ chrome.tabs.remove(sender.tab.id); }
  }catch(e){ sendResponse({error:e.message}); }
  return false;
});
