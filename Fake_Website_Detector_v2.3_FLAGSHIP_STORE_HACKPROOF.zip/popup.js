'use strict';
chrome.storage.local.get(["blockedCount","lastScam"], (data)=>{
  try{
    const el = document.getElementById("blocked");
    if(el) el.textContent = data.blockedCount || 0;
    const last = document.getElementById("last");
    if(last && data.lastScam){
      const h = (data.lastScam.host||"").replace(/</g,"&lt;");
      last.textContent = "Last blocked: " + h + " (" + (data.lastScam.type||"Scam") + ")";
    }
  }catch(e){}
});
