(function(){
  const rules=[
    {k:['my approvals','myapprovals'],tag:'My Approvals Fraud',w:3},
    {k:['code','paste krein','paste karein','25980'],tag:'Code Paste Scam',w:3},
    {k:['bisp','25000','ehsaas','inaam'],tag:'BISP Scam',w:3},
    {k:['galti se','ghalti se'],tag:'Galti Se Scam',w:3},
    {k:['otp bata','otp de'],tag:'OTP Scam',w:3},
    {k:['account band','block ho'],tag:'Account Block',w:2},
    {k:['verify','approve kardo','48500'],tag:'Suspicious',w:2}
  ];
  function sanitize(s){return s.replace(/<[^>]*>/g,'').slice(0,500);}
  function detect(msgRaw){
    const msg=sanitize(msgRaw.toLowerCase());
    if(!msg.trim()) return {empty:true};
    let score=0,found=[];
    rules.forEach(r=>{r.k.forEach(kw=>{if(msg.includes(kw)){score+=r.w; if(!found.includes(r.tag)) found.push(r.tag);}});});
    if(/\b\d{4,6}\b/.test(msg) && (msg.includes('code')||msg.includes('paste'))){score+=3; if(!found.includes('Code Paste Scam')) found.push('Code Paste Scam');}
    return {isScam: score>=2, found, risk: score>=2? Math.min(60+score*10,98):92};
  }
  function render(res){
    const r=document.getElementById('result'); r.textContent=''; r.style.display='block';
    if(res.empty){r.className='result scam'; r.textContent='⚠️ Paste or speak first!'; return;}
    r.className=res.isScam?'result scam':'result safe';
    const t=document.createElement('div'); t.textContent=res.isScam? '🚨 VOICE SCAM! '+res.risk+'% Risk' : '✅ SAFE - '+res.risk+'%'; t.style.fontWeight='bold'; r.appendChild(t);
    if(res.found.length){const w=document.createElement('div'); w.style.marginTop='6px'; res.found.forEach(x=>{const s=document.createElement('span'); s.textContent=x; s.style.cssText='background:#ddf4ff;color:#0969da;padding:3px 8px;border-radius:20px;font-size:10px;margin:2px;display:inline-block;font-weight:bold;'; w.appendChild(s);}); r.appendChild(w);}
    const e=document.createElement('div'); e.style.cssText='font-size:11px;margin-top:8px;font-weight:normal;color:#333;'; e.textContent=res.isScam?'❌ Do NOT share code/OTP!':'Looks legit. Verify 3737.'; r.appendChild(e);
  }
  const tabText=document.getElementById('tabText'), tabVoice=document.getElementById('tabVoice'), panelText=document.getElementById('panelText'), panelVoice=document.getElementById('panelVoice');
  tabText.addEventListener('click',()=>{tabText.classList.add('active'); tabVoice.classList.remove('active'); panelText.style.display='block'; panelVoice.style.display='none';});
  tabVoice.addEventListener('click',()=>{tabVoice.classList.add('active'); tabText.classList.remove('active'); panelText.style.display='none'; panelVoice.style.display='block';});
  document.getElementById('btnText').addEventListener('click',()=>{render(detect(document.getElementById('msg').value));});
  document.querySelectorAll('.ex').forEach(el=>{el.addEventListener('click',()=>{document.getElementById('msg').value=el.dataset.text; tabText.click(); render(detect(el.dataset.text));});});

  // Voice
  const btnMic=document.getElementById('btnMic'), transcriptDiv=document.getElementById('transcript'), btnVoiceDetect=document.getElementById('btnVoiceDetect'), btnOpen=document.getElementById('btnOpenVoicePage');
  btnOpen.addEventListener('click',()=>{chrome.tabs.create({url: chrome.runtime.getURL('voice.html')});});
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  let recognition, finalTranscript='';
  if(!SR){btnMic.textContent='❌ Voice not supported'; btnMic.disabled=true;}
  else{
    recognition=new SR(); recognition.lang='en-PK'; recognition.continuous=false; recognition.interimResults=true;
    recognition.onstart=()=>{btnMic.classList.add('listening'); btnMic.textContent='🔴 Listening... bolo'; transcriptDiv.style.display='block'; transcriptDiv.textContent='Sun raha hoon...';};
    recognition.onresult=(e)=>{let interim=''; finalTranscript=''; for(let i=e.resultIndex;i<e.results.length;i++){const t=e.results[i][0].transcript; if(e.results[i].isFinal) finalTranscript+=t; else interim+=t;} transcriptDiv.textContent=finalTranscript||interim; if(finalTranscript) btnVoiceDetect.style.display='block';};
    recognition.onend=()=>{btnMic.classList.remove('listening'); btnMic.textContent='🎙️ Tap to Speak Again'; if(finalTranscript) render(detect(finalTranscript));};
    recognition.onerror=(e)=>{
      btnMic.classList.remove('listening');
      if(e.error==='not-allowed'){transcriptDiv.style.display='block'; transcriptDiv.textContent='🚫 Mic blocked! Click "Open Voice in New Tab" button, then Allow mic.'; btnMic.textContent='🔒 Blocked - Use New Tab';}
      else{transcriptDiv.textContent='Error: '+e.error; transcriptDiv.style.display='block'; btnMic.textContent='🎙️ Tap to Speak';}
    };
    btnMic.addEventListener('click',()=>{finalTranscript=''; transcriptDiv.textContent=''; try{recognition.start();}catch{try{recognition.stop();}catch{} setTimeout(()=>{try{recognition.start();}catch{}},300);}});
    btnVoiceDetect.addEventListener('click',()=>{render(detect(finalTranscript||transcriptDiv.textContent));});
  }
})();
