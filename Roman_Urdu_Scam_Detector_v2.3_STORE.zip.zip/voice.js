const rules=[
  {k:['my approvals','myapprovals'],tag:'My Approvals Fraud',w:3},
  {k:['code','paste krein','paste karein','25980'],tag:'Code Paste Scam',w:3},
  {k:['bisp','25000','ehsaas'],tag:'BISP Scam',w:3},
  {k:['galti se','ghalti se'],tag:'Galti Se Scam',w:3},
  {k:['otp bata','otp de'],tag:'OTP Scam',w:3},
  {k:['account band','block ho'],tag:'Account Block',w:2}
];
function detect(msgRaw){
  const msg=msgRaw.toLowerCase();
  let score=0,found=[];
  rules.forEach(r=>{r.k.forEach(kw=>{if(msg.includes(kw)){score+=r.w; if(!found.includes(r.tag)) found.push(r.tag);}});});
  if(/\b\d{4,6}\b/.test(msg) && (msg.includes('code')||msg.includes('paste'))){score+=3; if(!found.includes('Code Paste Scam')) found.push('Code Paste Scam');}
  return {isScam: score>=2, found, risk: score>=2? Math.min(60+score*10,98):92};
}
function render(res){
  const r=document.getElementById('result'); r.style.display='block';
  r.className=res.isScam?'result scam':'result safe';
  const title=res.isScam? '🚨 VOICE SCAM! '+res.risk+'% Risk' : '✅ SAFE - '+res.risk+'%';
  r.textContent='';
  const t=document.createElement('div'); t.textContent=title; t.style.fontWeight='bold'; r.appendChild(t);
  if(res.found.length){const w=document.createElement('div'); w.style.marginTop='6px'; res.found.forEach(x=>{const s=document.createElement('span'); s.textContent=x; s.style.cssText='background:#ddf4ff;color:#0969da;padding:3px 8px;border-radius:20px;font-size:10px;margin:2px;display:inline-block;font-weight:bold;'; w.appendChild(s);}); r.appendChild(w);}
}
const btn=document.getElementById('btnMic'), tDiv=document.getElementById('transcript');
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
let recog, finalT='';
if(!SR){btn.textContent='Not supported'; btn.disabled=true;}
else{
  recog=new SR(); recog.lang='en-PK'; recog.interimResults=true;
  recog.onstart=()=>{btn.classList.add('listening'); btn.textContent='🔴 Listening...';};
  recog.onresult=(e)=>{let interim=''; finalT=''; for(let i=e.resultIndex;i<e.results.length;i++){const txt=e.results[i][0].transcript; if(e.results[i].isFinal) finalT+=txt; else interim+=txt;} tDiv.textContent=finalT||interim; if(finalT) render(detect(finalT));};
  recog.onend=()=>{btn.classList.remove('listening'); btn.textContent='🎙️ Start Speaking Again';};
  recog.onerror=(e)=>{tDiv.textContent='Error: '+e.error+' - Click lock icon to Allow mic'; btn.classList.remove('listening');};
  btn.addEventListener('click',()=>{finalT=''; try{recog.start();}catch{try{recog.stop();}catch{} setTimeout(()=>{try{recog.start();}catch{}},200);}});
}
